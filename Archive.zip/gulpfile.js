const { series, parallel, watch } = require('gulp');
let run = require('gulp-run'),
    gulp = require('gulp'),
    sass = require('gulp-sass');
// vars
let path_css_dir = './styles/',
    path_sass_inner = './styles/scss/';

function serve_honkit () {
    return run('npx honkit serve').exec()
        .on('end', () => {
            console.log('Completed');
        })
}

function compile_scss() {
        return gulp.src([path_sass_inner + '**/*.scss'])
            .pipe(sass().on('error', sass.logError))
            .pipe(gulp.dest(path_css_dir));
}

function watch_scss() {
    watch(path_sass_inner +'**/*.scss', { queue: false }, parallel(compile_scss))
}

exports.default = parallel(serve_honkit, watch_scss);

// exports.serve = series(serve_honkit);
// exports.watch_scss = series(watch_scss);
